import './App.css';
import Navbar from './Components/Dashboard/Navbar';
// import Sidebar from './Components/Dashboard/Sidebar';
// import Main from './Components/Dashboard/Main';
// import Footer from './Components/Dashboard/Footer';
// import DateFormat from './Components/Dashboard/DateFormat';

function App() {
  return (
    <div>
    <Navbar/>
    </div>
  );
}

export default App;
