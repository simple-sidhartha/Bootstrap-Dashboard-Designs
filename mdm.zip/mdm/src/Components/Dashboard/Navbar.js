import React, {useState} from "react";
import dateFormat from 'react-date-object';
import "../../assets/css/style.css";
import "../../assets/vendor/bootstrap/css/bootstrap.min.css";
import "../../assets/vendor/bootstrap-icons/bootstrap-icons.css";

import ergo_logo from "../../assets/img/logo.png";
import Sidebar from "./Sidebar";
import Footer from "./Footer";
import Main from './Main';

  const Navbar = () => {  
  const [isVisible, setIsVisible] = useState(false);
  const date = new dateFormat();  
  
    const toggleVisibility = () => {
    setIsVisible(!isVisible);
    }
    return (
    <div>
    <header id="header" className="header fixed-top d-flex align-items-center">

    <div className="d-flex align-items-center justify-content-between">
      <a href="index.html" className="logo d-flex align-items-center">
        <img src={ergo_logo} alt=""/>
      </a> 

      <div>            
      <i className="bi bi-list toggle-sidebar-btn" onClick={toggleVisibility}> 
      {isVisible ? true : false}     
      </i>      
      {isVisible && <div className="toggle-sidebar sidebar"></div>}
      </div>
    </div>
  
    <nav className="header-nav ms-auto">
      <ul className="d-flex align-items-center">

        <li className="nav-item">
          <a className="nav-link" href="https://www.hdfcergo.com/" target="_blank">
            Home
          </a>
        </li>

        <li className="nav-item">
          <a className="nav-link" href="https://www.esticker.com/" target="_blank">
            eStecker
          </a>
        </li>

        <li className="nav-item">
          <a className="nav-link" href="#">
            Help
          </a>
        </li>    

        <li className="nav-item dropdown">

          <a className="nav-link nav-profile d-flex align-items-center" href="#" data-bs-toggle="dropdown">
            <span className="d-none d-md-block dropdown-toggle"><i className="bi bi-person"></i>Sidhartha Mishra</span>
          </a>

          <ul className="dropdown-menu dropdown-menu-end dropdown-menu-arrow profile">

            <li>
              <a className="dropdown-item d-flex align-items-center" href="#">
                <span>Sign Out</span>
              </a>
            </li>

          </ul>
        </li>
         <li className="nav-item">
          <a className="nav-link" href="#">
            <i className="bi bi-calendar"></i>
            {date.format("DD MMMM YYYY")}
          </a>
        </li>
      </ul>
    </nav>
  </header>
  
  <div>
  <Sidebar/>
  </div>
  <div>
  <Footer/>
  </div>
 </div>
  )
}

export default Navbar;