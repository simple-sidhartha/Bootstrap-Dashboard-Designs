import React from 'react';

const Main = () => {
    return(
    <div>
    <main id="main" class="main">
    <div class="pagetitle">
    <h1>Master Data Management</h1>
    </div>
    </main>
    </div>
    )
} 

export default Main;