import React from 'react';
import "../../assets/css/style.css";
import "../../assets/vendor/bootstrap/css/bootstrap.min.css";

const Footer = () => {
    return (
        <div>
   <footer id="footer" className="footer">   
   <ul className="footer-links">
     <li><a href="https://www.hdfcergo.com" target="_blank">HDFC ERGO</a></li>
     <li><a href="https://www.hdfcbank.com" target="_blank">HDFC Bank</a></li>
     <li><a href="https://hdfcinsurance.com" target="_blank">HDFC Standard Life</a></li>
     <li><a href="https://hdfcsec.com" target="_blank">HDFC Securities</a></li>
      <li><a href="https://hdfcrealty.com" target="_blank">HDFC Realty</a></li>
     <li><a href="https://hdfcfund.com" target="_blank">HDFC Mutual Fund</a></li>
     <li><a href="https://ergo.com" target="_blank">Ergo</a></li>
   </ul>
   <p align="center">&copy; 2024 HDFC ERGO. All rights reserved.</p>

  </footer>
    </div>
    )
} 

export default Footer;