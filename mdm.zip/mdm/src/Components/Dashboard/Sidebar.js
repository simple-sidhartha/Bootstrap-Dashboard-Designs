import React from "react";

const Sidebar = () => {
    return (
        <div>
        <aside id="sidebar" class="sidebar">
        <ul className="sidebar-nav" id="sidebar-nav">

      <li className="nav-item">
        <a className="nav-link collapsed" data-bs-target="#components-nav" data-bs-toggle="collapse" href="#">
          <span>Main Menu</span><i className="bi bi-chevron-down ms-auto"></i>
        </a>
        <ul id="components-nav" className="nav-content collapse show" data-bs-parent="#sidebar-nav">
          <li>
            <a href="#">
             <span>Applications</span>
            </a>
          </li>
          <li>
            <a href="#">
              <span>DWH Mail</span>
            </a>
          </li>
          <li>
            <a href="#">
              <span>Deal Management</span>
            </a>
          </li>
          <li>
            <a href="#">
              <span>Master</span>
            </a>
          </li>
          <li>
            <a href="#">
              <span>Reports</span>
            </a>
          </li>
      
        </ul>
      </li>

    </ul>

  </aside>
        </div>
    )
} 

export default Sidebar